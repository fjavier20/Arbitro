LIGA SABATINA DE SABANCUY — PROTOTIPO PERSONALIZADO

Incluye: acta arbitral, firmas táctiles, equipos y plantillas locales, registro de incidencias y tarjetas, resumen disciplinario, personalización de colores/logotipo, exportación e importación de respaldos JSON, y archivos PWA.

Prueba: abre index.html en un navegador moderno. Para instalar desde Chrome Android y usar caché offline, aloja todos los archivos en HTTPS, abre la URL y selecciona Instalar aplicación / Agregar a pantalla principal.

IMPORTANTE: el PDF se genera mediante Imprimir > Guardar como PDF. El respaldo en la nube NO está conectado; esta versión guarda datos localmente y permite exportar/importar JSON. La pantalla de nube guarda solamente notas del proyecto Firebase; no sincroniza datos. Para nube real hace falta configurar Firebase Auth/Firestore, reglas de seguridad y pruebas. El logotipo inicial es temporal; en Personalizar liga puedes cargar el escudo oficial.

Este es un prototipo inicial, no una certificación legal del acta. Revisa los campos y las reglas de tu liga antes de usarlo oficialmente.
